% Min-Max normalization
function [vect,dmn,dmx] = minmaxnorm(X,stats)
if nargin == 1
    dmx = max(X,[],2);
    dmn = min(X,[],2);
elseif nargin == 2
    dmn = stats(:,1);
    dmx = stats(:,2);
end
N = size(X,2);
mx = repmat(dmx,1,N);
mn = repmat(dmn,1,N);
vect = (2.*(X - mn)./((mx-mn)+1e-6))-1; % [-1,1]
%vect = (X - mn)./(mx-mn); % [0,1]