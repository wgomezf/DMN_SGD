% Pattern classification using a smooth dendrite morphological neuron 
% learned via stochastic gradient descent.
%
% Reference:
% Wilfrido Gomez-Flores and Humberto Sossa. "Learning Smooth Dendrite 
% Morphological Neurons by Stochastic Gradient Descent for Pattern 
% Classification". Neural Networks, in revision, 2023.

function [Y,Z] = dsn_predict(dsn,X)
c = cat(1,dsn.classes);
d = cat(1,dsn.dimensions);
n = size(X,2);
mnmx  = @(x)(bsxfun(@minus,x,max(x,[],1))); % z=x-max(x) for numerically stable softmax and smooth maximum functions
pmax  = @(a,u)(bsxfun(@rdivide,exp(a*u),sum(exp(a*u),1))); % Equation C.1
smax  = @(u,p,m,a)(sum(bsxfun(@times,p(a,m(u)),u),1)); % Smooth maximum function (Equation C.6)
XX  = reshape(X,d,1,n);
sjk = cell(1,c);
yk  = zeros(c,n);
for i = 1:c
    X_C = bsxfun(@minus,XX,dsn(i).C);   
    Dk  = reshape(sum(X_C.^2,1),dsn(i).k,n); % Squared Euclidean distance
    sjk{i}  = bsxfun(@minus,dsn(i).r,Dk); % Dendrite response (Equation 1)
    yk(i,:) = smax(sjk{i},pmax,mnmx,dsn(c+2).beta); % Cluster of dendrites reponse (Equation 2)
end
yk = cat(1,ones(1,n),yk); % Add dummy variable for bias computation
ul = dsn(c+1).W'*yk;    % Linear combination (Equation 5)
Z  = softmax(mnmx(ul)); % Softmax layer (Equation 4)
[~,Y] = max(Z,[],1);    % Predicted class label (Equation 6)