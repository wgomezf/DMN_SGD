% Multiclass Matthews correlation coefficient
% recommended for imbalanced classes
function [mc,C] = mMCC(Yp,Yt,NC)
% Create confusion matrix
C = zeros(NC);
for i = 1:NC
    for j = 1:NC
        C(i,j) = sum((Yt==i)&(Yp==j));
    end
end
C = C+eps;
% Compute multiclass Matthews correlation coefficient
Skl_num  = 0;
Skl_den1 = 0;
Skl_den2 = 0;
Ct  = C';
N  = numel(Yt);
N2 = N*N;
for k = 1:NC
    for l = 1:NC
        Skl_num  = Skl_num  + sum(C(k,:).*C(:,l)');
        Skl_den1 = Skl_den1 + sum(C(k,:).*Ct(:,l)');
        Skl_den2 = Skl_den2 + sum(Ct(k,:).*C(:,l)');
    end
end
mc = (N*trace(C) - Skl_num)/(sqrt(N2 - Skl_den1)*sqrt(N2 - Skl_den2));
if isnan(mc)
    mc = 0;
end
    