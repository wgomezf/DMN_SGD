% This demo performs the learning of a smooth dendrite morphological neuron 
% via stochastic gradient descent. The hyperparameters smoothness factor (beta) 
% and the learning rate (eta) are prefixed.
%
% Reference:
% Wilfrido Gomez-Flores and Humberto Sossa. "Learning Smooth Dendrite 
% Morphological Neurons by Stochastic Gradient Descent for Pattern 
% Classification". Neural Networks, in revision, 2023.

clearvars; close all; clc;

path0 = fullfile(pwd,'synthetic/');
dirOutput = dir(fullfile(path0,'*.mat'));
fileNames = {dirOutput.name}';
for i = 1:numel(fileNames)
    fprintf('%d. %s\n',i,fileNames{i});
end
opt = input('Select a dataset: ');
% Predefined hyperparameters
% eta - learning rate
% beta - smoothness factor
switch opt
    case 1
        eta = 0.06;     beta = 7.5;
    case 2
        eta = 6.09e-4;  beta = 5.5;
    case 3
        eta = 3.51e-4;  beta = 3.2;
    case 4
        eta = 0.01;     beta = 4.2;
    case 5
        eta = 0.06;     beta = 2.8;
    case 6
        eta = 0.01;     beta = 6.1;
    case 7
        eta = 0.01;     beta = 0.6;
    case 8
        eta = 0.01;     beta = 19.6;
    case 9
        eta = 0.05;     beta = 2.2;
end

% Load dataset
load(fullfile(pwd,'synthetic/',fileNames{opt}));

% Data normalization
[Xtr,mn,mx] = minmaxnorm(Xtr);
Xtt = minmaxnorm(Xtt,[mn mx]);

% 2D grid points
s = 800;
[x1,x2] = meshgrid(linspace(-1.1,1.1,s),linspace(-1.1,1.1,s));
X = [x1(:) x2(:)]';

% Train DSN
dsn = dsn_train_sgd(Xtr,Ytr,beta,0.01,eta,200);

% Classify test data
[Ypp,Zpp] = dsn_predict(dsn,Xtt);

% Classify grid data
[Y,Z] = dsn_predict(dsn,X);
Y = reshape(Y,s,s);

% Plot results
mrk = {'o' '+' 'v'};
col1 = [1 1 0;1 0 1;0 1 1];
col2 = 1-col1;
figure('color',[1 1 1]);
subplot(2,2,1);
for i = 1:max(Ytt)
    pp = plot(Xtt(1,Ytt==i),Xtt(2,Ytt==i),mrk{i},'Color',col1(i,:));
    hold on;
    plot(dsn(i).C(1,:),dsn(i).C(2,:),'.','Color',col2(i,:));
    for j = 1:dsn(i).k
        viscircles(dsn(i).C(:,j)',dsn(i).r(j)^0.5,'linewidth',1,'Color',col2(i,:));
    end
end
axis([-1 1 -1 1]); 
axis square; 
axis xy;
set(gca,'XTick',[],'YTick',[]);
title('Spherical dendrites');

subplot(2,2,2);
imagesc(x1(:),x2(:),Y); 
hold on;
for i = 1:max(Ytt)
    plot(Xtt(1,Ytt==i),Xtt(2,Ytt==i),mrk{i},'Color',col1(i,:));
end
axis([-1 1 -1 1]); 
axis square; 
axis xy;
set(gca,'XTick',[],'YTick',[]);
title(sprintf('Decision regions. MCC=%0.3f',mMCC(Ypp,Ytt,max(Ytt))));

nit = numel(dsn(end).LearnCurve.Iters);
nep = numel(dsn(end).LearnCurve.Epochs);

subplot(2,2,[3 4]);
plot(1:nit,dsn(end).LearnCurve.Iters); 
hold on;
plot(1:nit/nep:nit,dsn(end).LearnCurve.Epochs); 
axis([1 nit 0 1]);
title('Learning curve');
ylabel('Loss','FontSize',12);
xlabel('Iterations','FontSize',12);