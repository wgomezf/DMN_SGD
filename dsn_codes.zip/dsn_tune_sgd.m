% Hyperparameter tuning via Bayesian optimization.
function [dsn,hpar,ttime] = dsn_tune_sgd(Xtr,Ytr,kf)
% Search ranges of hyperparameters
beta = optimizableVariable('beta',[0.1,20],'Type','real');      % Smoothness factor
eta  = optimizableVariable('eta',[1e-6,1e-1],'Type','real');	% Learning rate
% Cost function
fun  = @(x)kfoldError(Xtr,Ytr,kf,x.beta,x.eta);
% Tune hyperparameters with Bayesian optimization
tstart = tic;
results = bayesopt(fun,[beta,eta],'Verbose',0,'AcquisitionFunctionName','expected-improvement-per-second-plus','PlotFcn',[]);
ttime.tune = toc(tstart);
pars = table2array(results.XAtMinObjective);
hpar.beta = pars(1);
hpar.eta  = pars(2);
fprintf('Final DSN SGD - Beta: %0.3f - LR: %0.3e \n',hpar.beta,hpar.eta);
% Train the final model with the best hyperparameters
tstart = tic;
dsn = dsn_train_sgd(Xtr,Ytr,hpar.beta,0.01,hpar.eta,200);
ttime.train = toc(tstart);
%*********************************************************
function err = kfoldError(X,Y,kf,beta,eta)
K = max(kf);
err = zeros(1,K);
parfor k = 1:K
    err(k) = kth_error(X,Y,kf,k,beta,eta); % k-Fold experiments
end
err = mean(err); % Mean cross-validation performance
%********************************************************
function e = kth_error(X,Y,kf,k,beta,eta)
vd = kf==k;
tr = ~vd;
dsn = dsn_train_sgd(X(:,tr),Y(:,tr),beta,0.01,eta,200);
Ypp = dsn_predict(dsn,X(:,vd));
%e = mean(Ypp~=Y(:,vd)); % Error rate (not recommended for imbalanced classes)
e = mMCC(Ypp',Y(:,vd)',cat(1,dsn.classes)); % Matthews correlation coefficient
fprintf('DSN SGD - Fold: %d - Beta: %0.3f - LR: %0.3e - MCC: %0.3f\n',k,beta,eta,e);
e = (e+1)/2; % Rescales MCC from [-1,1] to [0,1]
e = 1-e;     % bayesopt minimices the cost function