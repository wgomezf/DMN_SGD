% Learning of a smooth dendrite morphological neuron 
% via stochastic gradient descent.
%
% Reference:
% Wilfrido Gomez-Flores and Humberto Sossa. "Learning Smooth Dendrite 
% Morphological Neurons by Stochastic Gradient Descent for Pattern 
% Classification". Neural Networks, in revision, 2023.

function dsn = dsn_train_sgd(X,Y,beta,tol,eta,epoch)
warning('off','all');
% Parameters
params.c = max(Y);      % Number of classes
params.d = size(X,1);   % Dimensionality
params.ntr = size(X,2); % Number of training patterns
params.ni = accumarray(Y',ones(numel(Y),1),[params.c 1],@sum,0); % Training patterns per class
params.dmax = round(2*sqrt(params.ni)); % Maximum number of dendrites
params.dmin = 2;       % Minimum number of patterns in a dendrite
params.beta = beta;    % Smooth factor
params.epoch = epoch;  % Number of epochs
params.tol = tol;      % Tolerance local error
params.eta = eta;      % Learning rate
params.batch = 32;     % Minibatch-size  arXiv:1206.5533 Practical recommendations for gradient-based training of deep architectures
% z=x-max(x) for numerically stable softmax and smooth maximum functions
params.mnmx  = @(x)(bsxfun(@minus,x,max(x,[],1))); 
% Smooth maximum function and its derivative
params.pmax  = @(a,u)(bsxfun(@rdivide,exp(a*u),sum(exp(a*u),1))); % Equation C.1
params.smax  = @(u,p,m,a)(sum(bsxfun(@times,p(a,m(u)),u),1)); % Equation C.6
params.dsmax = @(u,s,p,m,a)(p(a,m(u)).*(1+a*(u-s(u,p,m,a)))); % Equation C.8
% Softmax function
params.softmax = @(x)(bsxfun(@rdivide,exp(x),sum(exp(x),1)));
% Categorical cross-entropy loss
params.J = @(T,Z)(-sum(T.*log(Z+eps),1)); % Equation 10
% One-hot encoding
T = bsxfun(@eq,Y',meshgrid(1:params.c,1:params.ntr))';
% Initialize spheres' centroids with k-means
dsn = struct([]);        % Initialize dendrite structure
for i = 1:params.c
    Xc  = X(:,Y~=i)';    % It does not belong to ith class
    Xi  = X(:,Y==i)';    % It belongs to ith class
    k   = 0;             % Initializes number of dendrites
    err = Inf;
    while (err > params.tol) && (k <= params.dmax(i))
        k = k+1;
        [Yaux,Caux,~,Daux] = kmeans(Xi,k,'Distance','sqeuclidean','EmptyAction','drop','Replicates',10,'MaxIter',200,'Start','plus');
        if empty_dendrites(Caux,Yaux,k,params)
            break; % If it exists empty clusters, stop adding more dendrites
        else
            Ck = Caux; Yk = Yaux;   % Update current valid clusters
            Dk = min(Daux,[],2);    % Minimum distance to each cluster
            rk = zeros(1,k);
            for j = 1:k
                rk(j) = max(Dk(Yk==j)); % Calculate radius (Equation 7)
            end
            % Activate dendrites with patterns of other classes
            R = bsxfun(@minus,rk,pdist2(Xc,Ck,'squaredeuclidean')); 
            R = max(R,[],2); % Take maximum responses
            err = sum(R>=0)/size(Xc,1); % Detect positive responses (Equation 8)
            % Update current solution with non-empty dendrites
            dsn(i).C = Ck'; % Centroids
            dsn(i).r = rk'; % Radii
            dsn(i).k = k;   % Number of dendrites
        end
    end
end
% Weights initialization by Xavier method
W = normrnd(0,1/params.c,params.c+1,params.c); 
W(1,:) = 0; % Bias in zeros
dsn(params.c+1).W = W; % Output layer weights
dsn(params.c+2).beta = params.beta; % Smoothness factor
% Reshape data
XX  = reshape(X,params.d,1,params.ntr);
% Minibatch indices
imb = round(linspace(0,params.ntr,round(params.ntr/params.batch)));
nmb = numel(imb)-1; % Number of blocks
% Stochastic gradient descent optimization
Jtr = zeros(1,params.epoch);        % Learning curve by epoch
Jit = zeros(1,nmb*params.epoch);    % Learning curve by iteration (mini-batches)
cc  = 1;
for t = 1:params.epoch % For each epoch
    % Shuffle training data
    rnd = randperm(params.ntr);
    XX  = XX(:,:,rnd);
    X   = X(:,rnd);
    T   = T(:,rnd);
    Y   = Y(:,rnd);
    % Minibatch
    Jmb = zeros(1,nmb);
    for l = 1:nmb
        mb  = imb(l)+1:imb(l+1);
        XX2 = XX(:,:,mb);
        T2  = T(:,mb);
        Y2  = Y(:,mb);
        % Feed-forward
        [Z2,yk,sjk] = feed_forward(XX2,dsn,params); % Section 3.1
        % Mean loss
        Jmb(l) = mean(params.J(T2,Z2));
        Jit(cc) = Jmb(l); cc = cc+1;
        % Get gradients w.r.t. stochastic objective at timestep t
        % Softmax layer
        dl = Z2-T2;    % delta_l
        Dwkl = params.eta*yk*dl'; % Delta rule for weights (Equation 12)
        % Morphological layer
        Dcijk = cell(1,params.c); % Initialize centroid deltas
        for i = 1:params.c
            idx = Y2==i;
            Xi  = XX2(:,:,idx);
            % Derivative of the smooth maximum function (Equation 15)
            dk  = params.dsmax(sjk{i}(:,idx),params.smax,params.pmax,params.mnmx,dsn(params.c+2).beta); 
            t1  = bsxfun(@times,dsn(params.c+1).W(i+1,:)*dl(:,idx),dk); % Equation 14
            t2  = bsxfun(@minus,Xi,dsn(i).C); % Equation 16
            D   = reshape(sum(t2.^2,1),dsn(i).k,sum(idx)); % Squared Euclidean distance
            [~,L] = min(D,[],1); % Assign patterns to dendrites
            Cgr = zeros(params.d,dsn(i).k);
            for j = 1:dsn(i).k
                ij = L==j;
                Nj = sum(ij);
                if Nj >= params.dmin % If non-empty dendrite, update its centroid
                    Cgr(:,j) = sum(bsxfun(@times,reshape(t1(j,ij),1,1,Nj),2*t2(:,j,ij)),3);
                end
            end
            Dcijk{i} = params.eta*Cgr; % Delta rule for centroids (Equation 16)
        end
        % Update weights
        dsn(params.c+1).W = dsn(params.c+1).W - Dwkl;
        for i = 1:params.c
            % Update centers
            Ck = dsn(i).C - Dcijk{i};
            % Recalculate radii overall patterns of ith class
            Dk = pdist2(X(:,Y==i)',Ck','squaredeuclidean'); % Squared Euclidean distance
            [Dk,Yk] = min(Dk,[],2); % Assign patterns to dendrites
            rk = dsn(i).r;
            for j = 1:dsn(i).k
                idj = Yk==j;
                if sum(idj) >= params.dmin % If non-empty dendrite
                    rk(j) = max(Dk(idj)); % Update dendrite's radius (Equation 7)
                    if rk(j)==0 % This could happen if the centroid matches the same location of a pattern
                        % Recovers a previos state
                        rk(j) = dsn(i).r(j);
                        Ck(:,j) = dsn(i).C(:,j);
                    end
                else
                    % If empty dendrite recovers a previous state
                    Ck(:,j) = dsn(i).C(:,j); 
                end
            end
            % Save current solution
            dsn(i).r = rk;
            dsn(i).C = Ck;
            dsn(i).k = numel(rk);
        end
    end
    Jtr(t) = mean(Jmb);
end
dsn(params.c+3).classes = params.c;
dsn(params.c+4).dimensions = params.d;
dsn(params.c+5).LearnCurve.Epochs = Jtr; 
dsn(params.c+5).LearnCurve.Iters  = Jit; 

%***********************************************************************
% Detects if there are empty dendrites to stop adding dendrites
function flag = empty_dendrites(C,Y,k,params)
flag = false;
if any(isnan(C(:))) % If any NaN means that kmeans perform 'drop' 
    flag = true;    % so, there are empty clusters with no patterns assigened
else
    ki = accumarray(Y,ones(numel(Y),1),[k 1],@sum,0);
    if sum(ki<params.dmin)>0 % An empty dendrite also has less than dmin patterns
        flag = true;
    end
end
%***********************************************************************
% Performs DSN feed-forward to obtain posterior class probabilities
function [Z,yk,sjk] = feed_forward(XX,dsn,params)
params.ntr = size(XX,3);
sjk = cell(1,params.c);
yk  = zeros(params.c,params.ntr);
for i = 1:params.c
    X_C = bsxfun(@minus,XX,dsn(i).C);   
    Dk  = reshape(sum(X_C.^2,1),dsn(i).k,params.ntr); % Squared Euclidean distance
    sjk{i}  = bsxfun(@minus,dsn(i).r,Dk); % Dendrite response (Equation 1)
    yk(i,:) = params.smax(sjk{i},params.pmax,params.mnmx,dsn(params.c+2).beta); % Cluster of dendrites reponse (Equation 2)
end
yk = cat(1,ones(1,params.ntr),yk); % Add dummy variable for bias computation
ul = dsn(params.c+1).W'*yk; % Linear combination (Equation 5)
Z  = params.softmax(params.mnmx(ul)); % Softmax layer (Equation 4)